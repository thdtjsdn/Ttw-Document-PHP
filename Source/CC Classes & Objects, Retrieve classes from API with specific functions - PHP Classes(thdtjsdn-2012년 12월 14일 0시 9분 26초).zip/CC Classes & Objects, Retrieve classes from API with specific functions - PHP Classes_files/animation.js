/*
 *
 * @(#) $Id: animation.js,v 1.24 2012/11/24 09:52:20 mlemos Exp $
 *
 */

var ML;

if(ML === undefined)
{
	ML = { };
}

if(ML.Animation === undefined)
{
	ML.Animation = { };
}

if(ML.Animation.Utility === undefined)
{

ML.Animation.Utility =
{
	setOpacity: function(element, value)
	{
		element.style.opacity = element.style['-moz-opacity'] = element.style['-khtml-opacity'] = value;
		element.style.filter = 'alpha(opacity=' + Math.round(100*value) + ')';
		if(!element.currentStyle
		|| !element.currentStyle.hasLayout)
		{
			element.style.zoom = '100%';
		}
	},

	getElementSize: function(e, inner)
	{
		if(inner)
		{
			if(e.innerWidth)
			{
				return { width: e.innerWidth, height: e.innerHeight };
			}
			if(e.clientWidth)
			{
				return { width: e.clientWidth, height: e.clientHeight };
			}
		}
		else
		{
			if(typeof e.clip !== 'undefined')
			{
				return { width: e.clip.width, height: e.clip.height };
			}
		}
		return { width: e.offsetWidth, height: e.offsetHeight };
	}
};

}

if(ML.Animation.Effects === undefined)
{
ML.Animation.Effects = {

	AppendContent: function(effect)
	{
		this.start = function()
		{
			var e = document.getElementById(effect.element);
			if(e)
			{
				e.innerHTML += effect.content;
			}
			else
			{
				if(this.debug)
				{
					alert('Inexisting element "' + effect.element + '" of effect ' + this.animation.effect + ' "' + effect.type + '"');
				}
			}
			return true;
		};
	},

	CancelAnimation: function(effect)
	{
		this.start = function()
		{
			var a, c;

			for(a = 0, c = 0; a<ML.Animation.animations.length; a++)
			{
				if(ML.Animation.animations[a] !== null
				&& this.animation.animation !== a
				&& ML.Animation.animations[a].definition.name
				&& ML.Animation.animations[a].definition.name === effect.animation)
				{
					ML.Animation.cancelAnimation(ML.Animation.animations[a]);
					c++;
				}
			}
			if(c === 0
			&& this.debug
			&& this.debug >= 2)
			{
				alert('Inexisting animation to cancel "' + effect.animation + '" of effect ' + this.animation.effect);
			}
			return true;
		};
	},

	FadeIn: function(effect)
	{
		this.node = null;
		this.opacity = 0;

		this.start = function()
		{
			this.node = document.getElementById(effect.element);
			if(this.node)
			{
				this.opacity = 0;
				ML.Animation.Utility.setOpacity(this.node, this.opacity);
				if(effect.visibility === 'display')
				{
					this.node.style.display = 'block';
				}
				else
				{
					this.node.style.visibility = 'visible';
				}
				return false;
			}
			if(this.debug)
			{
				alert('Inexisting element "' + effect.element + '" of effect ' + this.animation.effect + ' "' + effect.type + '"');
			}
			return true;
		};

		this.step = function()
		{
			var p, opacity;

			p = (new Date().getTime() - this.startTime)/(this.duration*1000.0);
			if(p>1)
			{
				p = 1;
			}
			opacity = Math.round(p * ML.Animation.fadeStep) / ML.Animation.fadeStep;
			if(opacity !== this.opacity)
			{
				ML.Animation.Utility.setOpacity(this.node, this.opacity = opacity);
			}
			return (p < 1);
		};
	},

	FadeOut: function(effect)
	{
		this.node = null;
		this.opacity = 0;

		this.start = function()
		{
			this.node = document.getElementById(effect.element);
			if(this.node)
			{
				this.opacity = 1.0;
				ML.Animation.Utility.setOpacity(this.node, this.opacity);
				return false;
			}
			if(this.debug)
			{
				alert('Inexisting element "' + effect.element + '" of effect ' + this.animation.effect + ' "' + effect.type + '"');
			}
			return true;
		};

		this.step = function()
		{
			var p, opacity, step;

			p = (new Date().getTime() - this.startTime)/(this.duration*1000.0);
			if(p>1)
			{
				p = 1;
			}
			opacity = Math.round((1.0 - p) * ML.Animation.fadeStep) / ML.Animation.fadeStep;
			if(opacity !== this.opacity)
			{
				ML.Animation.Utility.setOpacity(this.node, this.opacity = opacity);
			}
			step = p < 1;
			if(!step)
			{
				if(effect.visibility === 'display')
				{
					this.node.style.display = 'none';
				}
				else
				{
					this.node.style.visibility = 'hidden';
				}
			}
			return step;
		};
	},

	Hide: function(effect)
	{
		this.start = function()
		{
			var e = document.getElementById(effect.element);
			if(e)
			{
				if(effect.visibility === 'display')
				{
					e.style.display = 'none';
				}
				else
				{
					e.node.style.visibility = 'hidden';
				}
			}
			else
			{
				if(this.debug)
				{
					alert('Inexisting element "' + effect.element + '" of effect ' + this.animation.effect + ' "' + effect.type + '"');
				}
			}
			return true;
		};
	},

	PrependContent: function(effect)
	{
		this.start = function()
		{
			var e = document.getElementById(effect.element);
			if(e)
			{
				e.innerHTML = effect.content + e.innerHTML;
			}
			else
			{
				if(this.debug)
				{
					alert('Inexisting element "' + effect.element + '" of effect ' + this.animation.effect + ' "' + effect.type + '"');
				}
			}
			return true;
		};
	},

	ReplaceContent: function(effect)
	{
		this.start = function()
		{
			var e = document.getElementById(effect.element);
			if(e)
			{
				e.innerHTML = effect.content;
			}
			else
			{
				if(this.debug)
				{
					alert('Inexisting element "' + effect.element + '" of effect ' + this.animation.effect + ' "' + effect.type + '"');
				}
			}
			return true;
		};
	},

	Show: function(effect)
	{
		this.start = function()
		{
			var e = document.getElementById(effect.element);
			if(e)
			{
				if(effect.visibility === 'display')
				{
					e.style.display = 'block';
				}
				else
				{
					e.style.visibility = 'visible';
				}
			}
			else
			{
				if(this.debug)
				{
					alert('Inexisting element "' + effect.element + '" of effect ' + this.animation.effect + ' "' + effect.type + '"');
				}
			}
			return true;
		};
	},

	SlideIn: function(effect)
	{
		this.node =
		this.parent =
		this.edge = 
		this.size = 
		this.oldEdge =
		this.oldPosition = null;

		this.start = function()
		{
			var size;

			this.node = document.getElementById(effect.element);
			if(this.node)
			{
				this.parent = document.createElement('div');
				this.parent.style.overflow = 'hidden';
				this.node.style.display = 'block';
				size = ML.Animation.Utility.getElementSize(this.node, false);
				switch(effect.edge)
				{
					case 'top':
						this.edge = this.size = size.height;
						this.oldEdge = this.node.style.bottom;
						this.node.style.bottom = this.edge + 'px';
						this.parent.style.height = '0';
						break;

					case 'bottom':
						this.edge = this.size = size.height;
						this.oldEdge = this.node.style.top;
						this.node.style.top = this.edge + 'px';
						this.parent.style.height = '0';
						break;

					case 'left':
						this.edge = this.size = size.width;
						this.oldEdge = this.node.style.right;
						this.node.style.right = this.edge + 'px';
						this.parent.style.width = '0';
						break;

					case 'right':
						this.edge = this.size = size.width;
						this.oldEdge = this.node.style.left;
						this.node.style.left = this.edge + 'px';
						this.parent.style.width = '0';
						break;

					default:
						if(this.debug)
						{
							alert('Invalid ' + effect.type + ' effect edge "' + effect.edge);
							this.parent = null;
							return true;
						}
				}
				this.oldPosition = this.node.style.position;
				this.node.style.position = 'relative';
				this.node.parentNode.insertBefore(this.parent, this.node);
				this.node.parentNode.removeChild(this.node);
				this.parent.appendChild(this.node);
				return false;
			}
			if(this.debug)
			{
				alert('Inexisting element "' + effect.element + '" of effect ' + this.animation.effect + ' "' + effect.type + '"');
			}
			return true;
		};

		this.step = function()
		{
			var p, edge, step;

			p = (new Date().getTime() - this.startTime)/(this.duration*1000.0);
			if(p>1)
			{
				p = 1;
			}
			edge = Math.round(this.size * (1 - p));
			if(edge !== this.edge)
			{
				this.edge = edge;
				switch(effect.edge)
				{
					case 'top':
						this.node.style.bottom = this.edge + 'px';
						this.parent.style.height = (this.size - this.edge) + 'px';
						break;

					case 'bottom':
						this.node.style.top = this.edge + 'px';
						this.parent.style.height = (this.size - this.edge) + 'px';
						break;

					case 'left':
						this.node.style.right = this.edge + 'px';
						this.parent.style.width = (this.size - this.edge) + 'px';
						break;

					case 'right':
						this.node.style.left = this.edge + 'px';
						this.parent.style.width = (this.size - this.edge) + 'px';
						break;
				}
			}
			step = (p < 1);
			if(!step)
			{
				this.parent.removeChild(this.node);
				this.parent.parentNode.insertBefore(this.node, this.parent);
				switch(effect.edge)
				{
					case 'top':
						this.node.style.bottom = this.oldEdge;
						break;

					case 'bottom':
						this.node.style.top = this.oldEdge;
						break;

					case 'left':
						this.node.style.right = this.oldEdge;
						break;

					case 'right':
						this.node.style.left = this.oldEdge;
						break;
				}
				this.node.style.position = this.oldPosition;
				this.parent.parentNode.removeChild(this.parent);
				this.parent = null;
			}
			return step;
		};
	},

	SlideOut: function(effect)
	{
		this.node =
		this.parent =
		this.edge = 
		this.size = 
		this.oldEdge =
		this.oldPosition = null;

		this.start = function()
		{
			var size;

			this.node = document.getElementById(effect.element);
			if(this.node)
			{
				this.parent = document.createElement('div');
				this.parent.style.overflow = 'hidden';
				this.node.style.display = 'block';
				size = ML.Animation.Utility.getElementSize(this.node, false);
				switch(effect.edge)
				{
					case 'top':
						this.parent.style.height = this.edge = this.size = size.height;
						this.oldEdge = this.node.style.bottom;
						this.node.style.bottom = this.edge + 'px';
						break;

					case 'bottom':
						this.parent.style.height = this.edge = this.size = size.height;
						this.oldEdge = this.node.style.top;
						this.node.style.top = this.edge + 'px';
						break;

					case 'left':
						this.parent.style.width = this.edge = this.size = size.width;
						this.oldEdge = this.node.style.right;
						this.node.style.right = this.edge + 'px';
						break;

					case 'right':
						this.parent.style.width = this.edge = this.size = size.width;
						this.oldEdge = this.node.style.left;
						this.node.style.left = this.edge + 'px';
						break;

					default:
						if(this.debug)
						{
							alert('Invalid ' + effect.type + ' effect edge "' + effect.edge);
							this.parent = null;
							return true;
						}
				}
				this.oldPosition = this.node.style.position;
				this.node.style.position = 'relative';
				this.node.parentNode.insertBefore(this.parent, this.node);
				this.node.parentNode.removeChild(this.node);
				this.parent.appendChild(this.node);
				return false;
			}
			if(this.debug)
			{
				alert('Inexisting element "' + effect.element + '" of effect ' + this.animation.effect + ' "' + effect.type + '"');
			}
			return true;
		};

		this.step = function()
		{
			var p, edge, step;

			p = (new Date().getTime() - this.startTime)/(this.duration*1000.0);
			if(p>1)
			{
				p = 1;
			}
			edge = Math.round(this.size * p);
			if(edge !== this.edge)
			{
				this.edge = edge;
				switch(effect.edge)
				{
					case 'top':
						this.node.style.bottom = this.edge + 'px';
						this.parent.style.height = (this.size - this.edge) + 'px';
						break;

					case 'bottom':
						this.node.style.top = this.edge + 'px';
						this.parent.style.height = (this.size - this.edge) + 'px';
						break;

					case 'left':
						this.node.style.right = this.edge + 'px';
						this.parent.style.width = (this.size - this.edge) + 'px';
						break;

					case 'right':
						this.node.style.left = this.edge + 'px';
						this.parent.style.width = (this.size - this.edge) + 'px';
						break;
				}
			}
			step = (p < 1);
			if(!step)
			{
				this.parent.removeChild(this.node);
				this.parent.parentNode.insertBefore(this.node, this.parent);
				switch(effect.edge)
				{
					case 'top':
						this.node.style.bottom = this.oldEdge;
						break;

					case 'bottom':
						this.node.style.top = this.oldEdge;
						break;

					case 'left':
						this.node.style.right = this.oldEdge;
						break;

					case 'right':
						this.node.style.left = this.oldEdge;
						break;
				}
				this.node.style.position = this.oldPosition;
				this.parent.parentNode.removeChild(this.parent);
				this.parent = null;
				this.node.style.display = 'none';
			}
			return step;
		};
	},

	Wait: function(effect)
	{
		this.start = function()
		{
			return false;
		};

		this.step = function()
		{
			return (new Date().getTime() - this.startTime < this.duration*1000.0);
		};
	}

};

ML.Animation.registerEffects = function(name, effects)
{
	if(ML.Animation.Effects[name] !== undefined)
	{
		return false;
	}
	ML.Animation.Effects[name] = effects;
	return true;
};

}

if(ML.Animation.Animate === undefined)
{
ML.Animation.animations = [];
ML.Animation.running = 0;
ML.Animation.poll = null;
ML.Animation.frameRate = 120;
ML.Animation.fadeStep = 100;
ML.Animation.defaultDuration = 1;

ML.Animation.cancelAnimation = function(animation)
{
	ML.Animation.animations[animation.animation] = null;
	if(--ML.Animation.running === 0)
	{
		clearInterval(ML.Animation.poll);
		ML.Animation.poll = null;
	}
};

ML.Animation.Animate = function()
{
	var advanceAnimation,
		stepEffects,
		startEffect;

	advanceAnimation = function(animation)
	{
		animation.running = false;
		if(++animation.effect < animation.definition.effects.length)
		{
			startEffect(animation);
		}
		else
		{
			ML.Animation.cancelAnimation(animation);
		}
	};

	stepEffects = function()
	{
		var a, animation, effect, step;

		for(a = 0; a<ML.Animation.animations.length; a++)
		{
			if(ML.Animation.animations[a] !== null
			&& ML.Animation.animations[a].running)
			{
				animation = ML.Animation.animations[a];
				effect = animation.definition.effects[animation.effect];
				step = effect.effect.step();
				if(!step)
				{
					advanceAnimation(animation);
				}
			}
		}
	};

	startEffect = function(animation)
	{
		var effect = animation.definition.effects[animation.effect],
			type = effect.type,
			advance, e, timeout;

		if(ML.Animation.Effects[type] === undefined)
		{
			if(animation.definition.debug)
			{
				alert('Unsupported animation type "' + type + '"');
			}
			advance = true;
		}
		else
		{
			e = effect.effect = new ML.Animation.Effects[type](effect);
			e.animation = animation;
			e.debug = animation.definition.debug;
			e.startTime = new Date().getTime();
			e.duration = (effect.duration === undefined ? ML.Animation.defaultDuration : effect.duration);
			advance = e.start();
		}
		if(advance)
		{
			effect.effect = null;
			advanceAnimation(animation);
		}
		else
		{
			if(ML.Animation.poll === null)
			{
				timeout = 1000 / ML.Animation.frameRate;
				ML.Animation.poll = setInterval(stepEffects, timeout < 1 ? 1 : timeout);
			}
			animation.running = true;
		}
	};

	this.addAnimation = function(animation)
	{
		var a = ML.Animation.animations.length;

		ML.Animation.animations[a] = { definition: animation, animation: a, effect: 0, running: false };
		ML.Animation.running++;
		startEffect(ML.Animation.animations[a]);
		return a;
	};
};

}
